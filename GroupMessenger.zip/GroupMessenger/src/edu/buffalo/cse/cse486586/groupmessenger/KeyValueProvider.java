package edu.buffalo.cse.cse486586.groupmessenger;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;

public class KeyValueProvider extends ContentProvider {
	
	private final String AUTHORITY = "edu.buffalo.cse.cse486586.groupmessenger.provider";
	private Uri mUri; 
	Context c;
	
	

	@Override
	public int delete(Uri arg0, String arg1, String[] arg2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getType(Uri arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri arg0, ContentValues cv) {
		// TODO Auto-generated method stub
		Set<String> keyValue = cv.keySet();
		Object[] keyValueArray =  keyValue.toArray();
		
		String VALUE = (String) cv.get((String) keyValueArray[0]);
		String FILENAME = (String) cv.get((String) keyValueArray[1]);
		
		FileOutputStream fos;
		try {
			fos = c.openFileOutput(FILENAME, Context.MODE_PRIVATE);
			fos.write(VALUE.getBytes());
			fos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return null;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		
		mUri = buildUri("content", "edu.buffalo.cse.cse486586.groupmessenger.provider");
		c = getContext();
		
		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] arg1, String key, String[] arg3,
			String arg4) {
		// TODO Auto-generated method stub
		int index;
		String[] columnNames = {"key","value"};
		MatrixCursor cursor = new MatrixCursor(columnNames);
		String test="";
	
		FileInputStream fis;
		try {
			fis = c.openFileInput(key);
			while((index = fis.read()) != -1)
			{
				String str = Character.toString((char)index);
				
				test = test.concat(str);
			}
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		cursor.addRow(new Object[]{key,test});
		
		
		
		
		return cursor;
	}

	@Override
	public int update(Uri arg0, ContentValues arg1, String arg2, String[] arg3) {
		// TODO Auto-generated method stub
		return 0;
	}
	private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }
}
