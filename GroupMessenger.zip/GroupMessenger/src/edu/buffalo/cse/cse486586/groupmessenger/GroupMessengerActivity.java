package edu.buffalo.cse.cse486586.groupmessenger;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class GroupMessengerActivity extends Activity {

	ServerSocket serverSocket;
	TextView tv;
	int[] countVector = new int[3];
	String portStr;
	final int AVD0 = 0;
	final int AVD1 = 1;
	final int AVD2 = 2;
	int rg;
	int sg;
	int mID;
	Uri mUri;
	ContentValues cv;
	ContentResolver mContentResolver;

	int testIndex; // local sequence no. for test 1.
	int test2index; // local sequence no. for test 2.

	HashMap<String, Object> holdbackQ; // to store incoming messages
	HashMap<String, Object> sequencerQ; // store in queue if conditions for
										// causal ordering are not met.
	HashMap<String, Object> holdbackorderQ; // store order messages in queue if
											// main messages are not there yet.

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_group_messenger);

		mUri = buildUri("content",
				"edu.buffalo.cse.cse486586.groupmessenger.provider"); // Uri for
																		// accessing
																		// content
																		// provider
		rg = 0;
		sg = 0;
		mID = 0;
		testIndex = 0;
		test2index = 0;
		countVector[0] = 0;
		countVector[1] = 0;
		countVector[2] = 0;

		holdbackQ = new HashMap<String, Object>();
		sequencerQ = new HashMap<String, Object>();
		holdbackorderQ = new HashMap<String, Object>();
		mContentResolver = getContentResolver();
		tv = (TextView) findViewById(R.id.textView1);
		tv.setMovementMethod(new ScrollingMovementMethod());
		findViewById(R.id.button1).setOnClickListener(
				new OnPTestClickListener(tv, getContentResolver()));

		// Get the emulator console port number

		TelephonyManager tel =

		(TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

		portStr = tel.getLine1Number().substring(
				tel.getLine1Number().length() - 4);

		// Establishing server socket connection to port 10000
		try {
			serverSocket = new ServerSocket(10000);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Starting the server task.
		new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
				serverSocket);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
		return true;
	}

	public void sendMessage(View view) {
		// Do something in response to button click
		EditText editText = (EditText) findViewById(R.id.editText1);
		String message = editText.getText().toString();

		editText.setText("");

		String[] values = new String[2];
		values[0] = portStr;
		values[1] = message;

		// send values to client.
		new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
				values);

	}

	public void onClickTest1(View view) {

		// spawn thread for Test 1.

		new TotalTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
				portStr);

	}

	public void onClickTest2(View view) {

		// spawn thread for Test 2.
		new TotalCausalTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,
				portStr);
	}

	private class TotalCausalTask extends AsyncTask<String, String, Void> {

		@Override
		protected Void doInBackground(String... port) {
			// TODO Auto-generated method stub

			String portStr = port[0];

			String avd;
			String messageID;
			int[] count = new int[3];
			count = countVector.clone();

			GroupMessage gm = new GroupMessage();

			// getting port according to emulator console port.
			if (portStr.equals("5554")) {
				avd = "avd0";
				count[0] = count[0] + 1;
			} else if (portStr.equals("5556")) {
				avd = "avd1";
				count[1] = count[1] + 1;
			} else {
				avd = "avd2";
				count[2] = count[2] + 1;
			}

			messageID = avd + mID;
			mID++;
			gm.setTestIndex(test2index);
			test2index++;
			gm.setCountVector(count);
			gm.setAvd(avd);
			gm.setID(messageID);
			gm.setType("Test2");
			multicast(gm); // multi-cast the first message for test 2.

			return null;
		}

	}

	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			// TODO Auto-generated method stub

			ServerSocket serverSocket = sockets[0];
			Socket socket;
			try {
				while (true) {
					// listening to incoming connection in the background
					Log.v(portStr + "ServerTask Tag 1",
							"Establishing server connection");
					socket = serverSocket.accept();
					Log.v(portStr + "ServerTask Tag 2",
							"Server connection established");
					ObjectInputStream ois = new ObjectInputStream(
							socket.getInputStream());
					GroupMessage gm = (GroupMessage) ois.readObject();
					// checking the type of message and acting accordingly.
					if (gm.getType().equals("Normal")
							|| gm.getType().equals("Test1")
							|| gm.getType().equals("Test2")) {
						bDeliver(gm);
						if (portStr.equals("5558")) // AVD02 is the default
													// sequencer.
						{
							System.out.println("Heyyy its 5554");
							sequencer(gm);
						}
					} else if (gm.getType().equals("order")) {
						bODeliver(gm);
					}
					socket.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		private void bDeliver(GroupMessage gm) {
			// TODO Auto-generated method stub
			Log.v(portStr, gm.type);
			Log.v(portStr, gm.ID);
			Log.v(portStr, gm.displayMessage());
			String key = gm.getID();
			if (holdbackorderQ.get(key) != null) // Check if order msg for the
													// incoming msg has reached
													// before.
			{
				GroupMessage orderMsg = (GroupMessage) holdbackorderQ.get(key);
				int seq = orderMsg.getSequence();
				if (seq == rg) {
					gm.setSequence(seq);
					holdbackorderQ.remove(key);
					publishProgress(gm.displayMessage());

					// put in content provider
					cv = new ContentValues();
					String cvkey = gm.getSequence() + "";
					String cvalue = gm.displayMessage();
					cv.put("key", cvkey);
					cv.put("value", cvalue);
					mContentResolver.insert(mUri, cv);

					rg = seq+1;
					sg++;
					Log.v(portStr, "bDeliver : " + gm.type);
					if (gm.getType().equals("Test2")) {
						testImpl(); // Fire two messages for test2
					}
				}
			} else {
				holdbackQ.put(key, gm); // put the message in hold back queue.
			}

		}

		private void bODeliver(GroupMessage gm) {
			// TODO Auto-generated method stub

			Log.v(portStr, gm.getType());
			Log.v(portStr, Integer.toString(gm.sequence));
			Log.v(portStr, gm.ID);
			Log.v("bODeliver", "Enter bODeliver");
			String key = gm.getID();
			holdbackorderQ.put(key, gm);
			Iterator<Entry<String, Object>> itr_hboq = holdbackorderQ
					.entrySet().iterator();
			while (itr_hboq.hasNext()) // check if message is present in hold
										// back order queue
			{
				Log.v(portStr + "bODeliver", "Inside Iterator");

				Entry<String, Object> entry_hboq = itr_hboq.next();
				GroupMessage msg = (GroupMessage) entry_hboq.getValue();
				String orderID = msg.getID();

				if (holdbackQ.get(orderID) != null) // if the message exist in
													// hold back queue.
				{
					Log.v(portStr + "bODeliver", "Obtained match in holdback Q");
					int seqNo = msg.getSequence();
					if (seqNo == rg) {
						Log.v(portStr + "bODeliver", "sequence no. = rg");
						GroupMessage message = (GroupMessage) holdbackQ
								.get(orderID);
						message.setSequence(seqNo);
						rg = seqNo + 1;
						String avd = message.getAvd();
						if (avd.equals("avd0")) {
							countVector[AVD0]++;
						} else if (avd.equals("avd1")) {
							countVector[AVD1]++;
						} else {
							countVector[AVD2]++;
						}
						publishProgress(message.displayMessage());
						// put in content provider
						String cvkey = message.getSequence() + "";
						String cvalue = message.displayMessage();
						cv = new ContentValues();
						cv.put("key", cvkey);
						cv.put("value", cvalue);
						mContentResolver.insert(mUri, cv);
						holdbackQ.remove(message.getID());
						itr_hboq.remove();
						Log.v(portStr, "bDeliver : " + message.type);
						if (message.getType().equals("Test2")) {
							testImpl(); // Fire two messages for test2
						}

					}
				}

			}
		}

		protected void onProgressUpdate(String... strings) {
			tv.append(strings[0] + "\n");

			return;
		}

	}

	private class ClientTask extends AsyncTask<String, Void, Void> {

		@Override
		protected Void doInBackground(String... values) {
			// TODO Auto-generated method stub

			String portStr = values[0];
			String msg = values[1];
			String avd;
			String messageID;
			int[] count = new int[3];
			count = countVector.clone();

			GroupMessage gm = new GroupMessage();

			// getting port according to emulator console port.
			if (portStr.equals("5554")) {
				avd = "avd0";
				count[0] = count[0] + 1;
			} else if (portStr.equals("5556")) {
				avd = "avd1";
				count[1] = count[1] + 1;
			} else {
				avd = "avd2";
				count[2] = count[2] + 1;
			}

			messageID = avd + mID;
			mID++;
			gm.setCountVector(count);
			gm.setAvd(avd);
			gm.setMsg(msg);
			gm.setID(messageID);
			gm.setType("Normal");
			multicast(gm);

			return null;
		}

	}

	public void testImpl() {
		String port = portStr;

		String avd;
		String messageID;

		for (int i = 0; i < 2; i++) {

			int[] count = new int[3];
			count = countVector.clone();

			if (port.equals("5554")) {
				avd = "avd0";
				count[0] = count[0] + 1;
			} else if (port.equals("5556")) {
				avd = "avd1";
				count[1] = count[1] + 1;
			} else {
				avd = "avd2";
				count[2] = count[2] + 1;
			}

			GroupMessage gm = new GroupMessage();
			String msg = avd + ":" + test2index;
			messageID = avd + mID;
			mID++;
			gm.setCountVector(count);
			gm.setAvd(avd);
			gm.setMsg(msg);
			gm.setTestIndex(test2index);
			test2index++;
			gm.setID(messageID);
			gm.setType("Normal");
			multicast(gm);
		}

	}

	public void sequencer(GroupMessage gm) {
		// TODO Auto-generated method stub
		GroupMessage message = gm;
		String key = message.getID();
		sequencerQ.put(key, message);
		Iterator<Map.Entry<String, Object>> itr_seq = sequencerQ.entrySet()
				.iterator();
		while (itr_seq.hasNext()) {
			Entry<String, Object> entry = itr_seq.next();
			GroupMessage msg = (GroupMessage) entry.getValue();
			String avd = msg.getAvd();
			boolean b1 = false;
			boolean b2 = true;

			int avdno;
			if (avd.equals("avd0"))
				avdno = AVD0;
			else if (avd.equals("avd1"))
				avdno = AVD1;
			else
				avdno = AVD2;

			int[] c_vector = msg.getCountVector();

			// Check the conditions for causal ordering

			if (c_vector[avdno] == countVector[avdno] + 1)
				b1 = true;

			for (int i = 0; i < 3; i++) {
				if (i != avdno) {
					if (!(c_vector[i] <= countVector[i]))
						b2 = false;

				}
			}

			if (b1 && b2) // If conditions are met, allot sequence no. and send
							// order msg.
			{
				GroupMessage orderMsg = new GroupMessage();
				String ID = msg.getID();
				orderMsg.setID(ID);
				orderMsg.setType("order");
				orderMsg.setSequence(sg);
				itr_seq.remove();
				sg++;
				multicast(orderMsg);

			}
		}

	}

	private class TotalTask extends AsyncTask<String, String, Void> {

		@Override
		protected Void doInBackground(String... portStr) {
			// TODO Auto-generated method stub
			String port = portStr[0];

			String avd;
			String messageID;

			for (int i = 0; i < 5; i++) // send 5 messages
			{

				int[] count = new int[3];
				count = countVector.clone();

				if (port.equals("5554")) {
					avd = "avd0";
					count[0] = count[0] + 1;
				} else if (port.equals("5556")) {
					avd = "avd1";
					count[1] = count[1] + 1;
				} else {
					avd = "avd2";
					count[2] = count[2] + 1;
				}

				GroupMessage gm = new GroupMessage();
				messageID = avd + mID;
				mID++;
				gm.setCountVector(count);
				gm.setAvd(avd);
				gm.setTestIndex(testIndex);
				testIndex++;
				gm.setID(messageID);
				gm.setType("Test1");
				multicast(gm);
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			return null;
		}

	}

	public void multicast(Object o) {
		// TODO Auto-generated method stub

		int[] port = new int[3];
		port[0] = 11108;
		port[1] = 11112;
		port[2] = 11116;
		Socket[] socket = new Socket[port.length];

		GroupMessage gm = null;

		if (o instanceof GroupMessage) {
			gm = (GroupMessage) o;
		}

		InetAddress address = null;
		// PrintWriter writer = null;
		ObjectOutputStream oos = null;
		try {
			address = InetAddress.getByName("10.0.2.2");
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// getting port according to emulator console port.

		for (int i = 0; i < socket.length; i++) {
			try {
				socket[i] = new Socket(address, port[i]);
				oos = new ObjectOutputStream(socket[i].getOutputStream());
				// writer = new PrintWriter();
				// writer.println(msg);
				oos.writeObject(gm);
				oos.flush();
				oos.close();
				socket[i].close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}

}
