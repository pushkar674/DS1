package edu.buffalo.cse.cse486586.groupmessenger;

import java.io.Serializable;

public class GroupMessage implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String avd;
	String msg;
	String ID;
	String type;
	int sequence;
	int testIndex;
	public int getTestIndex() {
		return testIndex;
	}
	public void setTestIndex(int testIndex) {
		this.testIndex = testIndex;
	}
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	int[] countVector;
	
	public String getAvd() {
		return avd;
	}
	public void setAvd(String avd) {
		this.avd = avd;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public int[] getCountVector() {
		return countVector;
	}
	public void setCountVector(int[] countVector) {
		this.countVector = countVector.clone();
	}
	public String displayMessage()
	{
		if(type.equals("Normal"))
		{return(msg);}
		else
		{
		String message = avd+":"+testIndex;
		return message;
		}
	}
}
